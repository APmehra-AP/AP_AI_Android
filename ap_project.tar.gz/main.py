# Created by : Amarchand Meghwal

from kivy.lang import Builder
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, FadeTransition

from kivymd.app import MDApp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton

from gui.splash import SplashScreen
from gui.home import HomeScreen
from gui.chat import ChatScreen
from gui.voice import VoiceScreen
from gui.memory import MemoryScreen
from gui.tools import ToolsScreen
from gui.settings import SettingsScreen

Builder.load_file("gui/splash.kv")
Builder.load_file("gui/home.kv")
Builder.load_file("gui/chat.kv")
Builder.load_file("gui/voice.kv")
Builder.load_file("gui/memory.kv")
Builder.load_file("gui/tools.kv")
Builder.load_file("gui/settings.kv")


class APAI(MDApp):

    dialog = None

    def build(self):
        self.title = "AP AI"

        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Blue"

        sm = ScreenManager(
            transition=FadeTransition(duration=0.25)
        )

        sm.add_widget(SplashScreen(name="splash"))
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(ChatScreen(name="chat"))
        sm.add_widget(VoiceScreen(name="voice"))
        sm.add_widget(MemoryScreen(name="memory"))
        sm.add_widget(ToolsScreen(name="tools"))
        sm.add_widget(SettingsScreen(name="settings"))

        sm.current = "home"

        Window.bind(on_keyboard=self.on_back_button)

        return sm

    def on_back_button(self, window, key, *args):
        if key != 27:
            return False

        sm = self.root

        if sm.current != "home":
            sm.current = "home"
            return True

        self.show_exit_dialog()
        return True

    def show_exit_dialog(self):
        if self.dialog:
            self.dialog.open()
            return

        self.dialog = MDDialog(
            title="Exit AP AI?",
            text="Do you want to close AP AI?",
            buttons=[
                MDFlatButton(
                    text="CANCEL",
                    on_release=lambda x: self.dialog.dismiss()
                ),
                MDFlatButton(
                    text="EXIT",
                    on_release=lambda x: self.stop()
                ),
            ],
        )

        self.dialog.open()


if __name__ == "__main__":
    APAI().run()
